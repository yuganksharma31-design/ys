# Dhanavardhana Dreamcare Association — Full Package

This archive contains:
- frontend/ (Vite + React + Tailwind) — editable UI
- server/ (Express + Nodemailer) — contact endpoint
- Dockerfiles and docker-compose.yml for quick containerized run

## Quickstart (local, recommended)
1. Frontend only (dev):
   ```bash
   cd frontend
   npm install
   npm run dev
   ```
   Open http://localhost:5173

2. Backend only:
   ```bash
   cd server
   npm install
   # copy .env.example to .env and edit
   node server.js
   ```
   Backend listens on port defined in .env or 3001.

3. Full stack with Docker Compose:
   Fill the environment variables in your shell or use an env file, then run:
   ```bash
   docker compose up --build
   ```
   Frontend will be on port 80 and backend on 3001.

## Netlify notes
- The frontend form includes Netlify Forms attributes so you can deploy the frontend on Netlify without the backend.

## Customization
- Replace assets in frontend/public or update links in code.
- For production email, use SendGrid/SES SMTP credentials.
