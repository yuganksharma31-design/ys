/**
 * api/contact.js
 * Vercel serverless function to send email via SendGrid.
 * Expects POST JSON: { name, email, phone, interest, message }
 * Environment variables required in Vercel:
 *   SENDGRID_API_KEY, MAIL_TO, FROM_EMAIL (optional)
 */

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const body = req.body || {};
  const { name, email, phone, interest, message } = body;

  if (!email) return res.status(400).json({ error: 'Email required' });

  const SENDGRID_API_KEY = process.env.SENDGRID_API_KEY;
  const MAIL_TO = process.env.MAIL_TO;
  const FROM_EMAIL = process.env.FROM_EMAIL || 'no-reply@dhanavardhana.org';

  if (!SENDGRID_API_KEY || !MAIL_TO) {
    console.error('Missing SendGrid config');
    return res.status(500).json({ error: 'Email service not configured' });
  }

  const payload = {
    personalizations: [{ to: [{ email: MAIL_TO }], subject: `Contact form: ${interest || 'General'}` }],
    from: { email: FROM_EMAIL },
    content: [
      {
        type: 'text/plain',
        value: `Name: ${name || 'N/A'}\nEmail: ${email}\nPhone: ${phone || 'N/A'}\nInterest: ${interest || 'N/A'}\nMessage: ${message || ''}`
      }
    ]
  };

  try {
    const r = await fetch('https://api.sendgrid.com/v3/mail/send', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${SENDGRID_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    if (!r.ok) {
      const text = await r.text();
      console.error('SendGrid error', r.status, text);
      return res.status(502).json({ error: 'Failed to send email', details: text });
    }

    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error('SendGrid fetch error', err);
    return res.status(500).json({ error: 'Internal error' });
  }
}
