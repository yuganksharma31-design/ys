import React from 'react'

export default function App(){
  return (
    <div className='min-h-screen bg-gradient-to-b from-slate-50 to-white text-slate-900'>
      <header className='bg-gradient-to-r from-blue-50 to-transparent sticky top-0'>
        <div className='max-w-6xl mx-auto p-6 flex items-center justify-between'>
          <div className='flex items-center gap-4'>
            <div className='w-12 h-12 rounded-lg bg-blue-600 text-white font-bold flex items-center justify-center'>D</div>
            <div>
              <div className='font-bold'>Dhanavardhana</div>
              <div className='text-sm text-slate-500'>Dreamcare Association</div>
            </div>
          </div>
          <nav className='hidden md:block'>
            <a href='#services' className='mr-6 font-medium'>Services</a>
            <a href='#about' className='mr-6 font-medium'>About</a>
            <a href='#contact' className='font-medium'>Contact</a>
          </nav>
          <a href='#contact' className='bg-blue-600 text-white px-4 py-2 rounded-lg'>Get in touch</a>
        </div>
      </header>

      <main className='max-w-6xl mx-auto p-6'>
        <section className='grid md:grid-cols-2 gap-8 items-center py-8'>
          <div>
            <h1 className='text-3xl font-extrabold mb-4'>Supporting dreams, building a secure future</h1>
            <p className='text-slate-500 mb-4'>We provide financial planning, insurance advisory and community support aimed at helping families and small businesses reach their goals.</p>
            <div className='flex gap-3 flex-wrap'>
              <div className='bg-white p-3 rounded-lg shadow min-w-[150px]'>Personalized Plans<div className='text-sm text-slate-500'>Tailored advice</div></div>
              <div className='bg-white p-3 rounded-lg shadow min-w-[150px]'>Trusted Partners<div className='text-sm text-slate-500'>Experienced professionals</div></div>
              <div className='bg-white p-3 rounded-lg shadow min-w-[150px]'>Community First<div className='text-sm text-slate-500'>Workshops & projects</div></div>
            </div>
          </div>

          <aside className='bg-white rounded-xl shadow p-6'>
            <h3 className='text-lg font-semibold mb-3'>Request a callback</h3>
            <form id='contactForm' name='contact' method='POST' data-netlify='true' netlify-honeypot='bot-field'>
              <input type='hidden' name='form-name' value='contact' />
              <p className='sr-only'>If you are a bot, leave this blank: <input name='bot-field' /></p>
              <input name='name' placeholder='Full name' required className='w-full p-3 rounded-md border mb-2'/>
              <input name='email' type='email' placeholder='Email' required className='w-full p-3 rounded-md border mb-2'/>
              <input name='phone' placeholder='Phone' className='w-full p-3 rounded-md border mb-2'/>
              <select name='interest' className='w-full p-3 rounded-md border mb-2'><option>General</option><option>Insurance</option><option>Loans</option></select>
              <textarea name='message' rows='3' className='w-full p-3 rounded-md border mb-2' placeholder='Message (optional)'></textarea>
              <button type='submit' className='w-full bg-blue-600 text-white p-3 rounded-md font-bold'>Send request</button>
              <div id='formMsg' className='text-sm text-slate-500 mt-2' role='status' aria-live='polite'></div>
            </form>
          </aside>
        </section>

        <section id='services' className='py-6'>
          <h2 className='text-2xl font-semibold mb-4'>Our Services</h2>
          <div className='grid md:grid-cols-2 lg:grid-cols-4 gap-4'>
            <div className='bg-white p-4 rounded-lg shadow'><h4 className='font-semibold'>Insurance Advisory</h4><p className='text-sm text-slate-500'>Life, health and vehicle insurance guidance.</p></div>
            <div className='bg-white p-4 rounded-lg shadow'><h4 className='font-semibold'>Loan Assistance</h4><p className='text-sm text-slate-500'>Assistance for home & business loans.</p></div>
            <div className='bg-white p-4 rounded-lg shadow'><h4 className='font-semibold'>Financial Planning</h4><p className='text-sm text-slate-500'>Education and retirement planning.</p></div>
            <div className='bg-white p-4 rounded-lg shadow'><h4 className='font-semibold'>Community Programs</h4><p className='text-sm text-slate-500'>Workshops & micro-grants.</p></div>
          </div>
        </section>

        <section id='about' className='py-6 flex flex-col md:flex-row gap-6 items-center'>
          <div>
            <h2 className='text-2xl font-semibold'>About Dhanavardhana Dreamcare Association</h2>
            <p className='text-slate-500 max-w-xl'>We combine advisory services with community programs to create sustainable local impact. Our team focuses on transparency, education and long-term relationships.</p>
            <a href='#contact' className='inline-block mt-4 bg-blue-600 text-white px-4 py-2 rounded-lg'>Join our programs</a>
          </div>
          <img src='https://source.unsplash.com/collection/190727/800x600' alt='Community' className='w-full md:w-80 rounded-lg' />
        </section>

        <section id='contact' className='py-6'>
          <h2 className='text-2xl font-semibold mb-4'>Contact</h2>
          <div className='flex flex-col md:flex-row gap-4'>
            <div className='bg-white p-4 rounded-lg shadow flex-1'>
              <h4 className='font-semibold'>Office</h4>
              <p className='text-sm text-slate-500'>123 Dreamcare Road, City, State</p>
              <p className='text-sm'>Email: hello@dhanavardhana.org</p>
              <p className='text-sm'>Phone: +91 90000 00000</p>
            </div>
            <div className='bg-slate-50 p-4 rounded-lg shadow flex-1'>Map placeholder — replace with Google Maps embed.</div>
          </div>
        </section>
      </main>

      <footer className='bg-white mt-12'>
        <div className='max-w-6xl mx-auto p-6 flex items-center justify-between'>
          <div><strong>Dhanavardhana Dreamcare Association</strong><div className='text-sm text-slate-500'>© {new Date().getFullYear()} All rights reserved.</div></div>
          <div className='text-sm text-slate-500'>Designed for quick deployment — edit content, replace images and update links as needed.</div>
        </div>
      </footer>
    </div>
  )
}
